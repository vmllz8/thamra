import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="text-wrapper">9:41</div>
          </div>
          <div className="frame">
            <img
              className="icon"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-3.svg"
            />
            <img
              className="img"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-6.svg"
            />
          </div>
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-7.svg"
          />
          <div className="navbar">
            <div className="overlap-group">
              <div className="rectangle" />
              <div className="div">
                <img
                  className="vuesax-outline-frame"
                  alt="Vuesax outline frame"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-1.svg"
                />
                <div className="text-wrapper-2">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-1.svg"
              />
              <div className="text-wrapper-3">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="star"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-13.svg"
                />
                <img
                  className="rectangle-2"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
              </div>
              <div className="text-wrapper-4">قائمة المتصدرين</div>
              <img
                className="iconsax-linear-edit"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              />
              <div className="text-wrapper-5">مصحح ثمار</div>
              <img
                className="union"
                alt="Union"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-5.svg"
              />
              <div className="text-wrapper-6">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
              />
            </div>
          </div>
          <div className="components-tabs">
            <div className="home">
              <div className="text-wrapper-7">الواجبات</div>
            </div>
          </div>
          <img
            className="group"
            alt="Group"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095476-2@2x.png"
          />
          <div className="cards">
            <div className="components-button">
              <div className="components">
                <div className="internal">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-2">
                      <img
                        className="vector"
                        alt="Vector"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector.svg"
                      />
                      <img
                        className="vector-2"
                        alt="Vector"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-2.svg"
                      />
                      <img
                        className="vector-3"
                        alt="Vector"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-3.svg"
                      />
                    </div>
                  </div>
                  <div className="text-wrapper-8">مراجعة سورة العلق كاملة</div>
                  <div className="frame-2">
                    <div className="frame-3" />
                  </div>
                  <img
                    className="icons"
                    alt="Icons"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="components-wrapper">
              <div className="components">
                <div className="frame-wrapper">
                  <div className="frame-2">
                    <div className="frame-3">
                      <div className="text-wrapper-9">مراجعة سورة المدثر كاملة</div>
                    </div>
                  </div>
                </div>
                <div className="div-wrapper">
                  <div className="overlap-group-3">
                    <img
                      className="vector"
                      alt="Vector"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-4.svg"
                    />
                    <img
                      className="vector-2"
                      alt="Vector"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-8.svg"
                    />
                    <img
                      className="vector-3"
                      alt="Vector"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-9.svg"
                    />
                  </div>
                </div>
                <img
                  className="icons-x"
                  alt="Icons"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-10.svg"
                />
              </div>
            </div>
            <div className="components-button-2">
              <div className="components">
                <div className="internal-2">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-2">
                      <img
                        className="vector"
                        alt="Vector"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-10.svg"
                      />
                      <img
                        className="vector-2"
                        alt="Vector"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-11.svg"
                      />
                      <img
                        className="vector-3"
                        alt="Vector"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-12.svg"
                      />
                    </div>
                  </div>
                  <div className="frame-4">
                    <div className="frame-3">
                      <div className="text-wrapper-10">مراجعة سورة الفاتحة كاملة</div>
                    </div>
                  </div>
                </div>
                <img
                  className="icons-2"
                  alt="Icons"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-11.svg"
                />
              </div>
            </div>
            <div className="components-button-3">
              <div className="components">
                <div className="internal-3">
                  <div className="frame-2">
                    <div className="frame-3" />
                    <img
                      className="icons-3"
                      alt="Icons"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-12.svg"
                    />
                  </div>
                  <div className="text-wrapper-11">مراجعة سورة القارعة كاملة</div>
                </div>
                <div className="iconsax-outline-2">
                  <div className="overlap-group-4">
                    <img
                      className="vector"
                      alt="Vector"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-13.svg"
                    />
                    <img
                      className="vector-2"
                      alt="Vector"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-14.svg"
                    />
                    <img
                      className="vector-3"
                      alt="Vector"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-15.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="icons-4">
            <div className="ph-arrows-down-up-wrapper">
              <img
                className="ph-arrows-down-up"
                alt="Ph arrows down up"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ph-arrows-down-up-1.svg"
              />
            </div>
          </div>
          <img
            className="icons-5"
            alt="Icons"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-7.svg"
          />
          <div className="group-2">
            <div className="overlap-2">
              <img
                className="group-3"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8026-2@2x.png"
              />
              <div className="group-4">
                <div className="group-5">
                  <div className="overlap-group-5">
                    <div className="ellipse" />
                    <img
                      className="path"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44116-2.svg"
                    />
                    <img
                      className="path-2"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44117-2.svg"
                    />
                    <img
                      className="path-3"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44118-2.svg"
                    />
                    <img
                      className="path-4"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44119-2.svg"
                    />
                  </div>
                </div>
                <div className="group-6">
                  <div className="overlap-group-5">
                    <div className="ellipse" />
                    <img
                      className="path"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44120-2.svg"
                    />
                    <img
                      className="path-2"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44121-2.svg"
                    />
                    <img
                      className="path-3"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44122-2.svg"
                    />
                    <img
                      className="path-4"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44123-2.svg"
                    />
                  </div>
                </div>
              </div>
              <img
                className="group-7"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035-2.png"
              />
            </div>
            <img
              className="group-8"
              alt="Group"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8028-1@2x.png"
            />
          </div>
          <img
            className="group-9"
            alt="Group"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095495@2x.png"
          />
          <img
            className="icons-6"
            alt="Icons"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-8.svg"
          />
        </div>
      </div>
    </div>
  );
};

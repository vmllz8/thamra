/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { Icon } from "../../icons/Icon";
import { Icon1 } from "../../icons/Icon1";
import "./style.css";

export const Frame = ({ className, icon = <Icon className="icon-instance" /> }) => {
  return (
    <div className={`frame ${className}`}>
      {icon}
      <Icon1 className="icon-1" />
    </div>
  );
};

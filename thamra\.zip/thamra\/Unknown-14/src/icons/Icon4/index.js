export { Icon4 } from "./Icon4";

import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="name-wrapper">
        <div className="name">
          <div className="gr-from-to-t">
            <img
              className="img"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1.svg"
            />
            <div className="element">
              <div className="div">
                <div className="div-2">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group">
                      <div className="div-3" />
                      <div className="text-wrapper">1</div>
                    </div>
                  </div>
                  <div className="nickname-wrapper">
                    <div className="nickname">
                      <div className="name-2">القارئ ماهر المعيقلي</div>
                    </div>
                  </div>
                </div>
                <a
                  className="div-wrapper"
                  href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  <p className="p">
                    <span className="span">استمع</span>
                    <span className="text-wrapper-2">&nbsp;</span>
                  </p>
                </a>
              </div>
            </div>
            <img
              className="img"
              alt="Element"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
            />
            <div className="div">
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group">
                    <div className="ellipse" />
                    <div className="text-wrapper">2</div>
                  </div>
                </div>
                <div className="nickname-wrapper-2">
                  <div className="nickname-2">
                    <div className="name-3">القارئ عبدالرحمن السديس</div>
                  </div>
                </div>
              </div>
              <a
                className="div-wrapper"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="text-wrapper-3">استمع</div>
              </a>
            </div>
            <img
              className="img"
              alt="Element"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
            />
            <div className="div">
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group">
                    <div className="ellipse-2" />
                    <div className="text-wrapper">3</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname">
                    <div className="name-4">القارئ ياسر بن الدوسري</div>
                  </div>
                </div>
              </div>
              <a
                className="div-wrapper"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="text-wrapper-3">استمع</div>
              </a>
            </div>
            <img
              className="img"
              alt="Element"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
            />
            <div className="element-wrapper">
              <a
                className="element-2"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="div-2">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-2">
                      <div className="ellipse-3" />
                      <div className="text-wrapper-4">4</div>
                    </div>
                  </div>
                  <div className="frame">
                    <div className="nickname">
                      <div className="text-wrapper-5">القارئ سعود ال شريم</div>
                    </div>
                  </div>
                </div>
                <div className="element-3">
                  <div className="element-4">استمع</div>
                </div>
              </a>
            </div>
            <a
              className="element"
              href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
              rel="noopener noreferrer"
              target="_blank"
            >
              <div className="div">
                <div className="element-5">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-3">
                      <div className="ellipse-4" />
                      <div className="text-wrapper-6">5</div>
                    </div>
                  </div>
                  <div className="element-6">
                    <div className="nickname">
                      <div className="name-5">القارئ فيصل غزاوي</div>
                    </div>
                  </div>
                </div>
                <div className="div-wrapper">
                  <div className="text-wrapper-3">استمع</div>
                </div>
              </div>
            </a>
            <img
              className="img"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
            />
            <div className="div">
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group">
                    <div className="div-3" />
                    <div className="text-wrapper">6</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname">
                    <div className="text-wrapper-7">القارئ عبدالله الجهني</div>
                  </div>
                </div>
              </div>
              <a
                className="div-wrapper"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="text-wrapper-3">استمع</div>
              </a>
            </div>
            <img
              className="img"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
            />
            <a
              className="div"
              href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
              rel="noopener noreferrer"
              target="_blank"
            >
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group">
                    <div className="ellipse" />
                    <div className="text-wrapper">7</div>
                  </div>
                </div>
                <div className="nickname-wrapper-2">
                  <div className="nickname-3">
                    <div className="text-wrapper-8">القارئ بندر بليلة</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="text-wrapper-3">استمع</div>
              </div>
            </a>
            <img
              className="img"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-70@2x.png"
            />
            <div className="div">
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group">
                    <div className="ellipse-2" />
                    <div className="text-wrapper">8</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname">
                    <div className="text-wrapper-9">القارئ صالح المحيميد</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="text-wrapper-3">استمع</div>
              </div>
            </div>
            <img
              className="img"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-70@2x.png"
            />
            <div className="div">
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-4">
                    <div className="text-wrapper-10">9</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname-4">
                    <div className="text-wrapper-11">القارئ عادل الكلباني</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="text-wrapper-3">استمع</div>
              </div>
            </div>
            <img
              className="img"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-70@2x.png"
            />
            <div className="div">
              <div className="div-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-5">
                    <div className="text-wrapper-10">10</div>
                  </div>
                </div>
                <div className="frame-2">
                  <div className="nickname">
                    <div className="text-wrapper-12">القارئ صالح الطالب</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="text-wrapper-3">استمع</div>
              </div>
            </div>
            <img
              className="components"
              alt="Components"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/components-cardsinternal-open-info.png"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

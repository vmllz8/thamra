import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="div">
        <div className="overlap">
          <div className="group">
            <div className="ellipse" />
            <div className="ellipse-2" />
            <div className="ellipse-3" />
            <div className="text-wrapper">من نحن؟</div>
            <img
              className="logo-thmar"
              alt="Logo thmar"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/logo-thmar--2.png"
            />
            <p className="p">من فضلك اختر طريقة تسجيل الدخول</p>
          </div>
          <div className="ellipse-4" />
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <img
                className="vector"
                alt="Vector"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-7.svg"
              />
              <div className="rectangle" />
              <div className="rectangle-2" />
              <img
                className="sign-up"
                alt="Sign up"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/sign-up@2x.png"
              />
              <img
                className="img"
                alt="Sign up"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/sign-up-1@2x.png"
              />
            </div>
          </div>
          <p className="text-wrapper-2">
            تطبيق يساعدك في تصحيح قراءتك للقرآن الكريم&nbsp;&nbsp;
            <br />
            ويوفر ميزة الحلقات القرآنية الإلكترونية لتستطيع تسميع ما حفظت أينما كنت وتتنافس مع المسلمين بين جميع أنحاء
            العالم
          </p>
        </div>
        <div className="status-bar">
          <img
            className="battery"
            alt="Battery"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
          />
          <img
            className="wifi"
            alt="Wifi"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
          />
          <img
            className="cellular-connection"
            alt="Cellular connection"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
          />
          <div className="text-wrapper-3">9:41</div>
        </div>
      </div>
    </div>
  );
};

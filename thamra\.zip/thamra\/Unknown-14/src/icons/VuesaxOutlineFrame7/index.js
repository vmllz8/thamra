export { VuesaxOutlineFrame7 } from "./VuesaxOutlineFrame7";

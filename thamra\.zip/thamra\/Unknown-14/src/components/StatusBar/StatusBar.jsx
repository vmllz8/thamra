/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const StatusBar = ({
  darkMode,
  className,
  wifi = "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b140a0db68d09621762874/img/wifi-1.svg",
  divClassName,
}) => {
  return (
    <div className={`status-bar ${darkMode} ${className}`}>
      <img
        className="battery"
        alt="Battery"
        src={
          darkMode === "off"
            ? "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            : "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b140a0db68d09621762874/img/battery@2x.png"
        }
      />
      <img
        className="wifi"
        alt="Wifi"
        src={
          darkMode === "off"
            ? wifi
            : "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b140a0db68d09621762874/img/wifi.svg"
        }
      />
      <img
        className="cellular-connection"
        alt="Cellular connection"
        src={
          darkMode === "off"
            ? "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            : "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b140a0db68d09621762874/img/cellular-connection.svg"
        }
      />
      <div className={`text-wrapper ${divClassName}`}>9:41</div>
    </div>
  );
};

StatusBar.propTypes = {
  darkMode: PropTypes.oneOf(["off", "on"]),
  wifi: PropTypes.string,
};

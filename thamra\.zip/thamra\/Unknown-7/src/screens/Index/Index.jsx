import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="frame">
            <img
              className="icon"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-3.svg"
            />
            <img
              className="img"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-6.svg"
            />
          </div>
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="text-wrapper">9:41</div>
          </div>
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/texture-3.svg"
          />
          <div className="navbar">
            <div className="overlap-group">
              <div className="rectangle" />
              <div className="div">
                <img
                  className="vuesax-outline-frame"
                  alt="Vuesax outline frame"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-3.svg"
                />
                <div className="text-wrapper-2">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-1.svg"
              />
              <div className="text-wrapper-3">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="star"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-13.svg"
                />
                <img
                  className="rectangle-2"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
              </div>
              <div className="text-wrapper-4">قائمة المتصدرين</div>
              <img
                className="iconsax-linear-edit"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              />
              <div className="text-wrapper-5">مصحح ثمار</div>
              <img
                className="union"
                alt="Union"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/union-3.svg"
              />
              <div className="text-wrapper-6">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
              />
            </div>
          </div>
          <div className="choose">
            <div className="carb">
              <div className="text-wrapper-7">حلقة عامة</div>
            </div>
            <div className="element">
              <div className="text-wrapper-8">حلقة خاصة</div>
            </div>
          </div>
          <div className="carb-wrapper">
            <div className="div-wrapper">
              <div className="text-wrapper-9">استعراض الواجبات</div>
            </div>
          </div>
          <div className="inside">
            <div className="inside-th" />
          </div>
          <img
            className="group"
            alt="Group"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095476-1@2x.png"
          />
          <div className="gr-from-to-t">
            <img
              className="img-2"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1-1.svg"
            />
            <div className="element-wrapper">
              <div className="div-2">
                <div className="div-3">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-2">
                      <div className="div-4" />
                      <div className="text-wrapper-10">1</div>
                    </div>
                  </div>
                  <div className="nickname-wrapper">
                    <div className="nickname">
                      <div className="name">سارة محمد</div>
                    </div>
                  </div>
                </div>
                <a
                  className="div-wrapper-2"
                  href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  <div className="text-wrapper-11">انضم!</div>
                </a>
              </div>
            </div>
            <img
              className="img-2"
              alt="Element"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            />
            <div className="div-2">
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="ellipse" />
                    <div className="text-wrapper-10">2</div>
                  </div>
                </div>
                <div className="nickname-wrapper-2">
                  <div className="name-wrapper">
                    <div className="name-2">حمد خالد</div>
                  </div>
                </div>
              </div>
              <a
                className="div-wrapper-2"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="text-wrapper-11">انضم!</div>
              </a>
            </div>
            <img
              className="img-2"
              alt="Element"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            />
            <div className="div-2">
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="ellipse-2" />
                    <div className="text-wrapper-10">3</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname">
                    <div className="name-3">نورة أحمد</div>
                  </div>
                </div>
              </div>
              <a
                className="div-wrapper-2"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="text-wrapper-11">انضم!</div>
              </a>
            </div>
            <img
              className="img-2"
              alt="Element"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            />
            <div className="element-2">
              <a
                className="element-3"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="div-3">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-3">
                      <div className="ellipse-3" />
                      <div className="text-wrapper-12">4</div>
                    </div>
                  </div>
                  <div className="frame-2">
                    <div className="nickname">
                      <div className="text-wrapper-13">ثامر يوسف</div>
                    </div>
                  </div>
                </div>
                <div className="element-4">
                  <div className="element-5">انضممت!</div>
                </div>
              </a>
            </div>
            <a
              className="element-wrapper"
              href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
              rel="noopener noreferrer"
              target="_blank"
            >
              <div className="div-2">
                <div className="element-6">
                  <div className="overlap-group-wrapper">
                    <div className="overlap-group-4">
                      <div className="ellipse-4" />
                      <div className="text-wrapper-14">5</div>
                    </div>
                  </div>
                  <div className="element-7">
                    <div className="nickname">
                      <div className="name-4">فيصل علي</div>
                    </div>
                  </div>
                </div>
                <div className="div-wrapper-2">
                  <div className="text-wrapper-11">انضم!</div>
                </div>
              </div>
            </a>
            <img
              className="img-2"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            />
            <div className="div-2">
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="div-4" />
                    <div className="text-wrapper-10">6</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname">
                    <div className="text-wrapper-15">لمياء ثابت</div>
                  </div>
                </div>
              </div>
              <a
                className="div-wrapper-2"
                href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="text-wrapper-11">انضم!</div>
              </a>
            </div>
            <img
              className="img-2"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            />
            <a
              className="div-2"
              href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
              rel="noopener noreferrer"
              target="_blank"
            >
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="ellipse" />
                    <div className="text-wrapper-10">7</div>
                  </div>
                </div>
                <div className="nickname-wrapper-2">
                  <div className="nickname-2">
                    <div className="text-wrapper-16">خالد عبدالرحمن</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper-2">
                <div className="text-wrapper-11">انضم!</div>
              </div>
            </a>
            <img
              className="vector"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
            />
            <div className="div-2">
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="ellipse-2" />
                    <div className="text-wrapper-10">8</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname">
                    <div className="text-wrapper-17">سناء عثمان</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper-2">
                <div className="text-wrapper-11">انضم!</div>
              </div>
            </div>
            <img
              className="vector"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
            />
            <div className="div-2">
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-5">
                    <div className="text-wrapper-18">9</div>
                  </div>
                </div>
                <div className="nickname-wrapper">
                  <div className="nickname-3">
                    <div className="text-wrapper-19">رنا محمد</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper-2">
                <div className="text-wrapper-11">انضم!</div>
              </div>
            </div>
            <img
              className="vector"
              alt="Vector"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
            />
            <div className="div-2">
              <div className="div-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-6">
                    <div className="text-wrapper-18">10</div>
                  </div>
                </div>
                <div className="frame-3">
                  <div className="nickname">
                    <div className="text-wrapper-20">سلطان عبدالله</div>
                  </div>
                </div>
              </div>
              <div className="div-wrapper-2">
                <div className="text-wrapper-11">انضم!</div>
              </div>
            </div>
            <img
              className="components"
              alt="Components"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/components-cardsinternal-open-info-1.png"
            />
          </div>
          <div className="group-2">
            <div className="overlap-2">
              <img
                className="group-3"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/group-8026-2@2x.png"
              />
              <div className="group-4">
                <div className="group-5">
                  <div className="overlap-group-7">
                    <div className="ellipse-5" />
                    <img
                      className="path"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44116.svg"
                    />
                    <img
                      className="path-2"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/path-44117-2.svg"
                    />
                    <img
                      className="path-3"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/path-44118-2.svg"
                    />
                    <img
                      className="path-4"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44119.svg"
                    />
                  </div>
                </div>
                <div className="group-6">
                  <div className="overlap-group-7">
                    <div className="ellipse-5" />
                    <img
                      className="path"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/path-44120-2.svg"
                    />
                    <img
                      className="path-2"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44121.svg"
                    />
                    <img
                      className="path-3"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/path-44122-2.svg"
                    />
                    <img
                      className="path-4"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44123-1.svg"
                    />
                  </div>
                </div>
              </div>
              <img
                className="group-7"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035.png"
              />
            </div>
            <img
              className="group-8"
              alt="Group"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/group-8028-1@2x.png"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

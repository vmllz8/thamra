import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { StatusBar } from "../../components/StatusBar";
import { Icon4 } from "../../icons/Icon4";
import { VuesaxOutlineFrame7 } from "../../icons/VuesaxOutlineFrame7";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="rectangle" />
          <StatusBar
            className="status-bar-instance"
            darkMode="off"
            divClassName="design-component-instance-node"
            wifi="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
          />
          <Frame className="frame-28" icon={<Icon4 className="icon-4" />} />
          <div className="div" />
          <div className="text-wrapper-2">مصحح التلاوة</div>
          <img
            className="group"
            alt="Group"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095487.png"
          />
          <div className="icons">
            <div className="overlap-group">
              <img
                className="stop-svgrepo-com"
                alt="Stop svgrepo com"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/stop-svgrepo-com-1.svg"
              />
            </div>
          </div>
          <img
            className="icons-x"
            alt="Icons"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-5.svg"
          />
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-3.svg"
          />
          <div className="components-button">
            <div className="components" />
            <img
              className="img"
              alt="Icons"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-6.svg"
            />
            <img
              className="texture-2"
              alt="Texture"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-4.svg"
            />
          </div>
          <div className="text">{""}</div>
          <div className="navbar">
            <div className="overlap-2">
              <div className="rectangle-2" />
              <div className="frame-2">
                <VuesaxOutlineFrame7 className="vuesax-outline-frame" />
                <div className="text-wrapper-3">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard.svg"
              />
              <div className="text-wrapper-4">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="star"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-7.svg"
                />
                <img
                  className="rectangle-3"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b140c99afa7456efe23074/img/rectangle-65-14@2x.png"
                />
              </div>
              <div className="text-wrapper-5">قائمة المتصدرين</div>
              <Link to="/index">
                <img
                  className="iconsax-linear-edit"
                  alt="Iconsax linear"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2-2.svg"
                />
              </Link>
              <div className="text-wrapper-6">مصحح ثمار</div>
              <img
                className="union"
                alt="Union"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-2.svg"
              />
              <div className="text-wrapper-7">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3.svg"
              />
            </div>
          </div>
          <div className="text-wrapper-8">استمع للآيات بشكل صحيح:</div>
        </div>
      </div>
    </div>
  );
};

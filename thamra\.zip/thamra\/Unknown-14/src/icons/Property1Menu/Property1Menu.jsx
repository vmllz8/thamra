/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Menu = ({ className }) => {
  return (
    <svg
      className={`property-1-menu ${className}`}
      fill="none"
      height="48"
      viewBox="0 0 48 48"
      width="48"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path className="path" d="M8 18H40" stroke="black" strokeLinecap="round" strokeWidth="4" />
      <path className="path" d="M17.1431 30H40.0002" stroke="black" strokeLinecap="round" strokeWidth="4" />
    </svg>
  );
};

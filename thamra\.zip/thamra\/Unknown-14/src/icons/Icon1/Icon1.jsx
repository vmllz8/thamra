/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Icon1 = ({ className }) => {
  return (
    <svg
      className={`icon-1 ${className}`}
      fill="none"
      height="64"
      viewBox="0 0 64 64"
      width="64"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path className="path" d="M10.6667 24H53.3334" stroke="black" strokeLinecap="round" strokeWidth="5.33333" />
      <path className="path" d="M22.8574 40H53.3336" stroke="black" strokeLinecap="round" strokeWidth="5.33333" />
    </svg>
  );
};

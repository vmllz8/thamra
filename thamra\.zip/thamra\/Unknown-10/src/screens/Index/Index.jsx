import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <img
            className="right-background"
            alt="Right background"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/right-background.svg"
          />
          <div className="right-group">
            <div className="eamil-ID">
              <div className="overlap-group">
                <div className="rectangle" />
                <div className="text-wrapper">11223344556</div>
              </div>
            </div>
            <div className="div">
              <div className="password">
                <div className="overlap-2">
                  <div className="rectangle" />
                  <div className="text-wrapper-2">ادخل كلمة المرور</div>
                </div>
              </div>
              <div className="rectangle-2" />
              <img
                className="frame"
                alt="Frame"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/frame.svg"
              />
            </div>
            <div className="text-wrapper-3">نسيت كلمة المرور</div>
            <img
              className="login-now"
              alt="Login now"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/login-now.png"
            />
            <div className="or">
              <img
                className="line"
                alt="Line"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-1.svg"
              />
              <img
                className="img"
                alt="Line"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-2.svg"
              />
              <div className="text-wrapper-4">أو</div>
            </div>
            <div className="sign-up">
              <div className="div-wrapper">
                <div className="text-wrapper-5">تسجيل جديد</div>
              </div>
            </div>
            <div className="text-wrapper-6">كلمة المرور:</div>
          </div>
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="text-wrapper-7">9:41</div>
          </div>
          <img
            className="logo-thmar"
            alt="Logo thmar"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/logo-thmar--2.png"
          />
          <div className="text-wrapper-8">تسجيل الدخول كـــ طالب</div>
          <div className="text-wrapper-9">رقم الهوية:</div>
          <div className="rectangle-3" />
          <img
            className="mail-icon"
            alt="Mail icon"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/mail-icon@2x.png"
          />
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-1.svg"
          />
          <img
            className="icon"
            alt="Icon"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-1.svg"
          />
          <img
            className="icon-2"
            alt="Icon"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-2.svg"
          />
        </div>
      </div>
    </div>
  );
};

import { StatusBar } from ".";

export default {
  title: "Components/StatusBar",
  component: StatusBar,
  argTypes: {
    darkMode: {
      options: ["off", "on"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    darkMode: "off",
    className: {},
    wifi: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b140a0db68d09621762874/img/wifi-1.svg",
    divClassName: {},
  },
};

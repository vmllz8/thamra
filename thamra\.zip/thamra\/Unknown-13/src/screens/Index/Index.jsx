import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="carb" />
          <div className="div-wrapper">
            <div className="text-wrapper">50</div>
          </div>
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="div">9:41</div>
          </div>
          <div className="frame">
            <img
              className="icon"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon.svg"
            />
          </div>
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture.svg"
          />
          <div className="carb-2" />
          <img
            className="logo-thmar"
            alt="Logo thmar"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/logo-thmar--2.png"
          />
          <div className="text-wrapper-2">أهلا! user@</div>
          <div className="carb-3">
            <div className="carb-4">
              <div className="carb-5">
                <p className="p">
                  حلقات ثمار هي حلقات قرآنية تمكن الطالب من الدخول الى حلقات عامة وخاصة&nbsp;&nbsp;تهدف الى تحسين
                  قراءتهم وتعزيز مستواهم&nbsp;&nbsp;، حيث توفر&nbsp;&nbsp;الاداة فرصة للمعلم لتوجيه الطلاب وإدارة واجبات
                  إضافية لتعزيز تقدمهم خلال حلقات ثمار.
                </p>
              </div>
              <div className="carb-wrapper">
                <div className="carb-6">
                  <div className="text-wrapper-3">حلقات ثمار</div>
                </div>
              </div>
            </div>
            <p className="text-wrapper-4">
              أداة مصحح التلاوة صممت لتساعدك فهي تقوم بكتابة الأخطاء المتواجدة في تلاوتك لتصحهها.
            </p>
            <div className="carb-7">
              <div className="carb-8">
                <div className="text-wrapper-3">مصحح ثمار</div>
              </div>
            </div>
          </div>
          <img
            className="group"
            alt="Group"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477@2x.png"
          />
          <img
            className="star"
            alt="Star"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3.svg"
          />
          <img
            className="rectangle"
            alt="Rectangle"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65.svg"
          />
          <div className="navbar">
            <div className="overlap-group">
              <div className="rectangle-2" />
              <div className="frame-2">
                <img
                  className="vuesax-outline-frame"
                  alt="Vuesax outline frame"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame.svg"
                />
                <div className="text-wrapper-5">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard.svg"
              />
              <div className="text-wrapper-6">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="img"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-1.svg"
                />
                <img
                  className="rectangle-3"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
              </div>
              <div className="text-wrapper-7">قائمة المتصدرين</div>
              <img
                className="iconsax-linear-edit"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              />
              <div className="text-wrapper-8">مصحح ثمار</div>
              <img
                className="union"
                alt="Union"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union.svg"
              />
              <div className="text-wrapper-9">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="text-wrapper">9:41</div>
          </div>
          <div className="header">
            <img
              className="icon"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-3.svg"
            />
            <img
              className="img"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-1.svg"
            />
          </div>
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-5.svg"
          />
          <div className="navbar">
            <div className="overlap-group">
              <div className="rectangle" />
              <div className="frame">
                <img
                  className="vuesax-outline-frame"
                  alt="Vuesax outline frame"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-3.svg"
                />
                <div className="div">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-3.svg"
              />
              <div className="text-wrapper-2">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="star"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-1.svg"
                />
                <img
                  className="rectangle-2"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
              </div>
              <div className="text-wrapper-3">قائمة المتصدرين</div>
              <img
                className="iconsax-linear-edit"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              />
              <div className="text-wrapper-4">مصحح ثمار</div>
              <img
                className="union"
                alt="Union"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-3.svg"
              />
              <div className="text-wrapper-5">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
              />
            </div>
          </div>
          <img
            className="group"
            alt="Group"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095476@2x.png"
          />
          <div className="components-tabs">
            <div className="carb">
              <div className="text-wrapper-6">حلقة عامة</div>
            </div>
            <div className="div-wrapper">
              <div className="text-wrapper-7">حلقة خاصة</div>
            </div>
          </div>
          <div className="inside">
            <div className="overlap-2">
              <div className="inside-th" />
              <div className="gr-from-to">
                <img
                  className="vector"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1.svg"
                />
                <div className="components">
                  <div className="components-2">
                    <div className="frame-2">
                      <div className="overlap-group-wrapper">
                        <div className="overlap-group-2">
                          <div className="ellipse" />
                          <div className="text-wrapper-8">1</div>
                        </div>
                      </div>
                      <div className="nickname-wrapper">
                        <div className="nickname">
                          <div className="text-wrapper-9">حلقة مسجد دار الإيمان</div>
                        </div>
                      </div>
                    </div>
                    <a
                      className="components-button"
                      href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                      rel="noopener noreferrer"
                      target="_blank"
                    >
                      <div className="text-wrapper-10">انضم!</div>
                    </a>
                  </div>
                </div>
                <img
                  className="vector"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
                />
                <div className="components-2">
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <div className="ellipse-2" />
                        <div className="text-wrapper-8">2</div>
                      </div>
                    </div>
                    <div className="frame-3">
                      <div className="nickname-2">
                        <div className="text-wrapper-11">حلقة مسجد الوالدين</div>
                      </div>
                    </div>
                  </div>
                  <a
                    className="components-button"
                    href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <div className="text-wrapper-10">انضم!</div>
                  </a>
                </div>
                <img
                  className="vector"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
                />
                <div className="components-2">
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <div className="ellipse-3" />
                        <div className="text-wrapper-8">3</div>
                      </div>
                    </div>
                    <div className="nickname-wrapper">
                      <div className="nickname">
                        <div className="text-wrapper-12">حلقة دار البصائر</div>
                      </div>
                    </div>
                  </div>
                  <a
                    className="components-button"
                    href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <div className="text-wrapper-10">انضم!</div>
                  </a>
                </div>
                <img
                  className="vector"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
                />
                <div className="your-card">
                  <a
                    className="components-3"
                    href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <div className="frame-2">
                      <div className="overlap-group-wrapper">
                        <div className="overlap-group-3">
                          <div className="ellipse-4" />
                          <div className="text-wrapper-13">4</div>
                        </div>
                      </div>
                      <div className="frame-4">
                        <div className="nickname">
                          <p className="p">حلقة مسجد أسامة بن زيد</p>
                        </div>
                      </div>
                    </div>
                    <div className="components-button-2">
                      <div className="text-wrapper-14">انضممت!</div>
                    </div>
                  </a>
                </div>
                <a
                  className="components"
                  href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  <div className="components-2">
                    <div className="frame-5">
                      <div className="overlap-group-wrapper">
                        <div className="overlap-group-4">
                          <div className="ellipse-5" />
                          <div className="text-wrapper-15">5</div>
                        </div>
                      </div>
                      <div className="frame-6">
                        <div className="nickname">
                          <p className="text-wrapper-16">حلقة مسجد أبي بن كعب</p>
                        </div>
                      </div>
                    </div>
                    <div className="components-button">
                      <div className="text-wrapper-10">انضم!</div>
                    </div>
                  </div>
                </a>
                <img
                  className="vector"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
                />
                <div className="components-2">
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <div className="ellipse" />
                        <div className="text-wrapper-8">6</div>
                      </div>
                    </div>
                    <div className="nickname-wrapper">
                      <div className="nickname">
                        <div className="text-wrapper-17">حلقة دار التبيان</div>
                      </div>
                    </div>
                  </div>
                  <a
                    className="components-button"
                    href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <div className="text-wrapper-10">انضم!</div>
                  </a>
                </div>
                <img
                  className="vector"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-69-1.svg"
                />
                <a
                  className="components-2"
                  href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <div className="ellipse-2" />
                        <div className="text-wrapper-8">7</div>
                      </div>
                    </div>
                    <div className="frame-3">
                      <div className="nickname-3">
                        <div className="text-wrapper-18">حلقة دار الرياحين</div>
                      </div>
                    </div>
                  </div>
                  <div className="components-button">
                    <div className="text-wrapper-10">انضم!</div>
                  </div>
                </a>
                <img
                  className="vector-2"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
                <div className="components-2">
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <div className="ellipse-3" />
                        <div className="text-wrapper-8">8</div>
                      </div>
                    </div>
                    <div className="nickname-wrapper">
                      <div className="nickname">
                        <div className="text-wrapper-19">حلقة مسجد ذي النورين</div>
                      </div>
                    </div>
                  </div>
                  <div className="components-button">
                    <div className="text-wrapper-10">انضم!</div>
                  </div>
                </div>
                <img
                  className="vector-2"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
                <div className="components-2">
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-5">
                        <div className="text-wrapper-20">9</div>
                      </div>
                    </div>
                    <div className="nickname-wrapper">
                      <div className="nickname-4">
                        <div className="text-wrapper-21">حلقة دار البراعم</div>
                      </div>
                    </div>
                  </div>
                  <div className="components-button">
                    <div className="text-wrapper-10">انضم!</div>
                  </div>
                </div>
                <img
                  className="vector-2"
                  alt="Vector"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
                <div className="components-2">
                  <div className="frame-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-6">
                        <div className="text-wrapper-20">10</div>
                      </div>
                    </div>
                    <div className="frame-7">
                      <div className="nickname">
                        <div className="text-wrapper-22">حلقة منار الريادة</div>
                      </div>
                    </div>
                  </div>
                  <div className="components-button">
                    <div className="text-wrapper-10">انضم!</div>
                  </div>
                </div>
                <img
                  className="components-4"
                  alt="Components"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/components-cardsinternal-open-info.png"
                />
              </div>
            </div>
          </div>
          <div className="carb-wrapper">
            <div className="carb-2">
              <div className="text-wrapper-23">استعراض الواجبات</div>
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-3">
              <div className="overlap-4">
                <img
                  className="group-3"
                  alt="Group"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8026@2x.png"
                />
                <div className="group-4">
                  <div className="group-5">
                    <div className="overlap-group-7">
                      <div className="ellipse-6" />
                      <img
                        className="path"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44116.svg"
                      />
                      <img
                        className="path-2"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44117.svg"
                      />
                      <img
                        className="path-3"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44118.svg"
                      />
                      <img
                        className="path-4"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44119.svg"
                      />
                    </div>
                  </div>
                  <div className="group-6">
                    <div className="overlap-group-7">
                      <div className="ellipse-6" />
                      <img
                        className="path"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44120.svg"
                      />
                      <img
                        className="path-2"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44121.svg"
                      />
                      <img
                        className="path-3"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44122.svg"
                      />
                      <img
                        className="path-4"
                        alt="Path"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44123.svg"
                      />
                    </div>
                  </div>
                </div>
                <img
                  className="group-7"
                  alt="Group"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035.png"
                />
              </div>
              <img
                className="group-8"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8028@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

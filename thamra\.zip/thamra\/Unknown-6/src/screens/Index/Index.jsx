import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="div">
        <div className="overlap">
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="text-wrapper">9:41</div>
          </div>
          <div className="frame">
            <img
              className="icon"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-3.svg"
            />
            <img
              className="img"
              alt="Icon"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-4.svg"
            />
          </div>
          <div className="rectangle" />
          <div className="text-wrapper-2">قائمة المتصدرين</div>
          <div className="text-wrapper-3">50/800</div>
          <div className="rectangle-2" />
          <img
            className="line"
            alt="Line"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-3.svg"
          />
          <div className="group">
            <div className="overlap-group">
              <div className="rectangle-3" />
              <div className="text-wrapper-4">ثمارك</div>
            </div>
          </div>
          <div className="overlap-wrapper">
            <div className="overlap-2">
              <div className="overlap-group-2">
                <div className="rectangle-4" />
                <img
                  className="rectangle-5"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-77.svg"
                />
                <div className="text-wrapper-5">650/800</div>
              </div>
              <div className="text-wrapper-6">سارة محمد</div>
            </div>
          </div>
          <div className="overlap-group-wrapper">
            <div className="overlap-2">
              <div className="overlap-group-3">
                <div className="rectangle-4" />
                <div className="rectangle-6" />
                <div className="text-wrapper-7">450/800</div>
              </div>
              <div className="text-wrapper-8">أحمد ناصر</div>
            </div>
          </div>
          <div className="div-wrapper">
            <div className="overlap-2">
              <div className="overlap-group-4">
                <div className="rectangle-4" />
                <img
                  className="rectangle-7"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-81.png"
                />
                <div className="text-wrapper-9">250/800</div>
              </div>
              <div className="text-wrapper-10">عبدالله يوسف</div>
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-3">
              <div className="overlap-group-5">
                <img
                  className="rectangle-8"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-82.svg"
                />
                <div className="rectangle-9" />
                <div className="text-wrapper-11">25/800</div>
              </div>
              <div className="text-wrapper-12">تالا عبدالرحمن</div>
            </div>
            <img
              className="rectangle-10"
              alt="Rectangle"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-69.png"
            />
          </div>
          <div className="text-wrapper-13">@user</div>
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-2.svg"
          />
          <div className="navbar">
            <div className="overlap-4">
              <div className="rectangle-11" />
              <div className="frame-2">
                <img
                  className="vuesax-outline-frame"
                  alt="Vuesax outline frame"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-1.svg"
                />
                <div className="text-wrapper-14">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-1.svg"
              />
              <div className="text-wrapper-15">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="star"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-2.svg"
                />
                <img
                  className="rectangle-12"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
              </div>
              <div className="text-wrapper-16">قائمة المتصدرين</div>
              <img
                className="iconsax-linear-edit"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              />
              <div className="text-wrapper-17">مصحح ثمار</div>
              <img
                className="union"
                alt="Union"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-1.svg"
              />
              <div className="text-wrapper-18">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
              />
            </div>
          </div>
          <div className="rectangle-13" />
          <div className="group-3">
            <div className="group-wrapper">
              <div className="group-4">
                <div className="star-wrapper">
                  <img
                    className="star-2"
                    alt="Star"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-3.svg"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="icons-othersizes-2">
            <div className="overlap-5">
              <img
                className="star-3"
                alt="Star"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
              />
              <img
                className="rectangle-14"
                alt="Rectangle"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-4.svg"
              />
            </div>
          </div>
          <div className="group-5">
            <div className="overlap-6">
              <img
                className="star-3"
                alt="Star"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-4.svg"
              />
              <img
                className="rectangle-14"
                alt="Rectangle"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-66.svg"
              />
            </div>
          </div>
          <div className="icons-othersizes-3">
            <div className="overlap-7">
              <img
                className="star-3"
                alt="Star"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
              />
              <img
                className="rectangle-14"
                alt="Rectangle"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-5.svg"
              />
            </div>
          </div>
          <div className="icons-othersizes-4">
            <div className="overlap-7">
              <img
                className="star-3"
                alt="Star"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
              />
              <img
                className="rectangle-14"
                alt="Rectangle"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-6.svg"
              />
            </div>
          </div>
        </div>
        <img
          className="ellipse"
          alt="Ellipse"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/ellipse-709@2x.png"
        />
      </div>
    </div>
  );
};

import React from "react";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="ranking-wrapper">
        <div className="ranking">
          <div className="overlap">
            <div className="element">
              <img
                className="img"
                alt="Vector"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1-1.svg"
              />
              <p className="div">
                <span className="text-wrapper">
                  المستوى الذهبي:
                  <br />
                </span>
                <span className="span">
                  {" "}
                  عندما تتألق بأكثر من 650 نقطة، تصبح نجمًا ذهبيًا في عالم قراءتك للقرآن. ذلك اللمعان الذهبي يعكس العناء
                  والتفاني الذي وضعته في فهم كلمات الله عز وجل. استمتع بلحظات التألق واستعد لمزيد من التحديات التي تعزز
                  من إشراقتك.
                  <br />
                </span>
              </p>
              <img
                className="img"
                alt="Element"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
              />
              <p className="p">
                <span className="text-wrapper">المستوى الفضي:</span>
                <span className="span">
                  {" "}
                  بتحقيقك 450 نقطة، أنت الآن جزء من تلك الفرقة المتألقة بالفضة. استمتع بلحظات الفخر والإنجاز، وتذوق
                  حلاوة تقدمك. لا تنسى أن تُلهم الآخرين من حولك، حيث تكون قصتك نبراسًا يستنير به الطلاب الطامحون.
                </span>
              </p>
              <img
                className="img"
                alt="Element"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
              />
              <p className="element-2">
                <span className="text-wrapper">المستوى البرونزي:</span>
                <span className="span">
                  {" "}
                  بتحقيقك 250 نقطة، أنت الآن في بداية رحلتك القرآنية. استمر في السعي للتحسين واستفد من كل توجيه يقدمه
                  المعلم. تلك الخطوات الأولى تعد نقطة انطلاق قوية لتحقيق التقدم واستمرار التطور.
                </span>
              </p>
              <img
                className="img"
                alt="Element"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
              />
              <p className="div-2">
                <span className="text-wrapper">المستوى الأخضر:</span>
                <span className="span">
                  {" "}
                  عندما تكون في مستوى الأخضر، تكون في مرحلة محمسة من التحدي والتعلم. استمتع بكل لحظة من تطورك، وابحث عن
                  فرص التحسين المستمر. تفاعل مع المعلم وزملائك، واستمتع برحلة اكتشاف إمكانياتك في عالم القراءة والتلاوة.
                </span>
              </p>
              <div className="group">
                <div className="star-wrapper">
                  <img
                    className="star"
                    alt="Star"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-9.svg"
                  />
                </div>
              </div>
              <div className="icons-othersizes">
                <div className="overlap-group">
                  <img
                    className="star-2"
                    alt="Star"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
                  />
                  <img
                    className="rectangle"
                    alt="Rectangle"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-10.svg"
                  />
                </div>
              </div>
              <div className="overlap-wrapper">
                <div className="overlap-2">
                  <img
                    className="star"
                    alt="Star"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-4-1.svg"
                  />
                  <img
                    className="rectangle-2"
                    alt="Rectangle"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-66-1.svg"
                  />
                </div>
              </div>
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img
                    className="star-2"
                    alt="Star"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
                  />
                  <img
                    className="rectangle"
                    alt="Rectangle"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-11.svg"
                  />
                </div>
              </div>
            </div>
            <div className="components-tabs">
              <div className="home">
                <div className="text-wrapper-2">استعراض قائمة المتصدرين</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

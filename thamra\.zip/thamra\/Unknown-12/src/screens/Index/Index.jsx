import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="status-bar">
            <img
              className="battery"
              alt="Battery"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
            />
            <img
              className="wifi"
              alt="Wifi"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
            />
            <img
              className="cellular-connection"
              alt="Cellular connection"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
            />
            <div className="text-wrapper">9:41</div>
          </div>
          <img
            className="texture"
            alt="Texture"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-6.svg"
          />
          <div className="navbar">
            <div className="overlap-group">
              <div className="frame">
                <div className="div">
                  <Link to="/index">
                    <img
                      className="vuesax-outline-frame"
                      alt="Vuesax outline frame"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-1.svg"
                    />
                  </Link>
                  <img
                    className="union"
                    alt="Union"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-4.svg"
                  />
                </div>
                <div className="text-wrapper-2">الإعدادات</div>
              </div>
              <img
                className="iconsax-linear"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-4.svg"
              />
              <div className="text-wrapper-3">حلقات ثمار</div>
              <div className="icons-othersizes">
                <img
                  className="star"
                  alt="Star"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-2.svg"
                />
                <img
                  className="rectangle"
                  alt="Rectangle"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
                />
              </div>
              <div className="text-wrapper-4">قائمة المتصدرين</div>
              <img
                className="iconsax-linear-edit"
                alt="Iconsax linear"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2-4.svg"
              />
              <div className="text-wrapper-5">مصحح ثمار</div>
              <div className="text-wrapper-6">الرئيسية</div>
              <img
                className="iconsax-outline"
                alt="Iconsax outline"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
              />
            </div>
          </div>
          <img
            className="img"
            alt="Iconsax outline"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-heart.svg"
          />
          <p className="q-mind">
            <span className="span">صنع بـ</span>
            <span className="text-wrapper-7">&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span className="span">
              لتحدي التطبيقات القرآنية بواسطة فريق Q mind <br />
              2024©
            </span>
          </p>
          <div className="text-wrapper-8">تعديل معلوماتي</div>
          <div className="group">
            <div className="overlap-2">
              <img
                className="group-2"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8026-1@2x.png"
              />
              <div className="group-3">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="ellipse" />
                    <img
                      className="path"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44116-1.svg"
                    />
                    <img
                      className="path-2"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44117-1.svg"
                    />
                    <img
                      className="path-3"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44118-1.svg"
                    />
                    <img
                      className="path-4"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44119-1.svg"
                    />
                  </div>
                </div>
                <div className="div-wrapper">
                  <div className="overlap-group-2">
                    <div className="ellipse" />
                    <img
                      className="path"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44120-1.svg"
                    />
                    <img
                      className="path-2"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44121-1.svg"
                    />
                    <img
                      className="path-3"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44122-1.svg"
                    />
                    <img
                      className="path-4"
                      alt="Path"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44123-1.svg"
                    />
                  </div>
                </div>
              </div>
              <img
                className="group-4"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035.png"
              />
            </div>
          </div>
          <div className="group-5">
            <div className="overlap-3">
              <div className="components-tabs" />
              <div className="right-group">
                <div className="eamil-ID">
                  <div className="overlap-group-3">
                    <div className="rectangle-2" />
                    <div className="text-wrapper-9">ليان عبدالله المقرن</div>
                  </div>
                </div>
                <div className="password">
                  <div className="overlap-4">
                    <div className="rectangle-2" />
                    <img
                      className="ph-arrows-down-up"
                      alt="Ph arrows down up"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ph-arrows-down-up.svg"
                    />
                    <div className="text-wrapper-10">منطقة الرياض</div>
                  </div>
                </div>
                <div className="or">
                  <img
                    className="line"
                    alt="Line"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-1-1.svg"
                  />
                  <img
                    className="line-2"
                    alt="Line"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-2-1.svg"
                  />
                  <div className="text-wrapper-11">أو</div>
                </div>
                <div className="password-2">
                  <div className="overlap-5">
                    <div className="rectangle-2" />
                    <div className="text-wrapper-12">A1234567a</div>
                  </div>
                  <div className="text-wrapper-13">منطقة الرياض</div>
                </div>
                <div className="text-wrapper-14">المنطقة الإدارية:</div>
                <div className="text-wrapper-15">كلمة المرور:</div>
                <div className="carb">
                  <div className="text-wrapper-16">حفظ التغييرات</div>
                </div>
              </div>
              <div className="text-wrapper-17">الاسم:</div>
            </div>
          </div>
          <div className="sign-up">
            <div className="overlap-6">
              <div className="text-wrapper-18">تسجيل خروج</div>
            </div>
          </div>
          <img
            className="icon"
            alt="Icon"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-4.svg"
          />
        </div>
      </div>
    </div>
  );
};
